Council Tax Band Analysis
Abiola Abolarinwa

Includes the original public repository snapshot plus the additional project summary and four presentation images supplied on 9 November 2026.

Original repository: https://github.com/Harvey-bot-pro/-Council-Tax-property-counts-as-at-31-March-2026-Source-Valuation-Office-Agency.

Open documentation/Council_Tax_Project_Summary.docx for the project narrative. The repository folder contains the SQL, CSV and Power BI files. Property stock snapshot: 31 March 2026.
